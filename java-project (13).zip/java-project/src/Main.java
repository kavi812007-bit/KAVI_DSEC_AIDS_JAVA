// Online Java Compiler (Editor)
// Write and run Java online using this editor.
import java.util.Scanner;

 public class Main {
    public static void main(String[] args) {
    int a=16;
    String result=(a%2!=0)?"odd":"even";
    System.out.println(result);
    }
}
