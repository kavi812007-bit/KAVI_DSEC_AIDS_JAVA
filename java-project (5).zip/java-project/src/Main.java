// Online Java Compiler (Editor)
// Write and run Java online using this editor.
import java.util.Scanner;

 public class Main {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int a=18;
        int b=56;
        String result=(a>=b)?"PASS":"FAIL";
      
        System.out.println(result);
    }
}
