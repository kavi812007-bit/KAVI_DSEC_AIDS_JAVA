// Online Java Compiler (Editor)
// Write and run Java online using this editor.

class Main {
    public static void main(String[] args) {
        String name = "Priya";
        int age = 19;
        char grade = 'A';
        boolean placementStatus = false;
        System.out.println("name=+priya");
        System.out.println("age=+19");
        System.out.println("grade=+a");
        
    }
}
