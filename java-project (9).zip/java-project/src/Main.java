// Online Java Compiler (Editor)
// Write and run Java online using this editor.
import java.util.Scanner;

 public class Main {
    public static void main(String[] args) {
        boolean id=true;
        //boolean ticket=false;
        
      
        System.out.println(!id );
    }
}
