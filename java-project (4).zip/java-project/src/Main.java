// Online Java Compiler (Editor)
// Write and run Java online using this editor.

class Main {
    public static void main(String[] args) {
        System.out.println("name:=kavi");
        System.out.println("age=85");
        System.out.println("grade=a");
        
    }
}
