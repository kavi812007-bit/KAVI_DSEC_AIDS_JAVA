// Online Java Compiler (Editor)
// Write and run Java online using this editor.
import java.util.Scanner;

 public class Main {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int a=18;
        String result=(a>=18)?"Eligible":"Not Eligible";
      
        System.out.println(result);
    }
}
