// Online Java Compiler (Editor)
// Write and run Java online using this editor.
import java.util.Scanner;

 public class Main {
    public static void main(String[] args) {
     int id=10;
     int ticket=20;
     id+=ticket;
     System.out.println(id);
    }
}
