// Online Java Compiler (Editor)
// Write and run Java online using this editor.
import java.util.Scanner;

 public class Main {
    public static void main(String[] args) {
        
        int balance=1000;
        //System.out.println(balance);
        balance+=500;
        System.out.println(balance);
        balance-=200;
        System.out.println(balance);
        balance*=2;
      
        System.out.println(balance);
    }
}
