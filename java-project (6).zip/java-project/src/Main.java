// Online Java Compiler (Editor)
// Write and run Java online using this editor.
class Main {
    public static void main(String[] args) {
        String name = "Priya";
        int id = 66;
        double price = 800.00;
        System.out.println("name=+priya");
        System.out.println("age=+66");
        System.out.println("grade=+80");
        
    }
}
