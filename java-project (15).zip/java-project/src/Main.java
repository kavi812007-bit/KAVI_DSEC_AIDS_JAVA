// Online Java Compiler (Editor)
// Write and run Java online using this editor.
import java.util.Scanner;

 public class Main {
    public static void main(String[] args) {
    int a=16;
    int b=13;
    String result=(a<b)?"greater":"lesster";
    System.out.println(result);
    }
}
