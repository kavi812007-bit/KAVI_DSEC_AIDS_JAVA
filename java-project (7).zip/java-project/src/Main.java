// Online Java Compiler (Editor)
// Write and run Java online using this editor.
import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter city:");
        String city=sc.next();
        System.out.println("enter age:");
        int age=sc.nextInt();
        System.out.println("city=kalai");
        System.out.println("age=80");
    }
}
