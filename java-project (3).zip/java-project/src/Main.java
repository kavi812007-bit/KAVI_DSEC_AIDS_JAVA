// Online Java Compiler (Editor)
// Write and run Java online using this editor.
import java.util.Scanner;

 public class Main {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        int a=10;
        int b=20;
        int large=(a>b )? a:b;
        System.out.println("largest number:"+large);
    }
}
