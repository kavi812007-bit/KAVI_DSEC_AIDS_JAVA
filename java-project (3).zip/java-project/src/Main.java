// Online Java Compiler (Editor)
// Write and run Java online using this editor.

class Main {
    public static void main(String[] args) {
        System.out.println("name\t:arun");
        System.out.println("dept\t:aids");
        System.out.println("course\t:java");
    }
}
