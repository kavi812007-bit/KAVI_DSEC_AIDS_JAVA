// Online Java Compiler (Editor)
// Write and run Java online using this editor.

class Main {
    public static void main(String[] args) {
        System.out.println("college:dsec");
        System.out.println("dept:aids");
        System.out.println("course:java");
    }
}
